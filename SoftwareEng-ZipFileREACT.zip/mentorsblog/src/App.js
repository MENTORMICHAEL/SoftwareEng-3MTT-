import './index.css';

function App() {
  const title = 'Hello World';

  return (
    <div className="App">
      <h1> {title} </h1>
    </div>
  );
}

export default App;
